﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jsLibrary;

namespace PoliticInform
{
    public partial class Member : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        string sql = "";
        object sds = new object();
        SQLDB db = new SQLDB(SiteMaster.ConnStr);

        protected void MemberSearch(object sender, EventArgs e)
        {
            string name = tbMemberName.Text;
            if (name != null)
            {
                GridView1.DataSourceID = "";
                sql = $"select * from totalInfo where empNm like N'%{name}%'";
                sds = db.Run(sql);
                GridView1.DataSource = sds;
                GridView1.DataBind();
            }
        }

        //검색하여 db에서 찾아주기 membercurrstate와 memberdetailinfo 두개의 db를 사용함
        protected void btnMemberClick(object sender, EventArgs e)
        {
            string nm = tbMemberName.Text;
            string party = MemberParty.Text;
            string area = MemberArea.Text;
            string committ = MemberCommittee.Text;
            string times = MemberElectedTimes.Text;

            if (party == "전체") party = "";
            if (area == "전체") area = "";
            if (committ == "전체") committ = "";
            if (times == "전체") times = "";

            GridView1.DataSourceID = "";
            sql = $"select * from totalInfo where empNm like N'%{nm}%' and reeleGbnNm like N'%{times}%' and origNm like N'%{area}%' and polyNm like N'%{party}%' and shrtNm like N'%{committ}%'";
            sds = db.Run(sql);
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
        }

        protected void MemberReset_Click(object sender, EventArgs e)
        {
            tbMemberName.Text = "";
            MemberParty.Text = "전체";
            MemberArea.Text = "전체";
            MemberCommittee.Text = "전체";
            MemberElectedTimes.Text = "전체";
            GridView1.DataSourceID = "";
            sql = $"select * from totalInfo";
            sds = db.Run(sql);
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }
    }
}